package com.ofrs.Model;

public class RegisteredUser_Admin {
	
	private int id;
	private String userName;
	private String userEmail;
	private String contactNo;
	private String password;
	
	public RegisteredUser_Admin() {}

	public RegisteredUser_Admin(int id, String userName, String userEmail, String contactNo, String password) {
		super();
		this.id = id;
		this.userName = userName;
		this.userEmail = userEmail;
		this.contactNo = contactNo;
		this.password = password;
	}

	public RegisteredUser_Admin(int id, String userName, String userEmail, String contactNo) {
		super();
		this.id = id;
		this.userName = userName;
		this.userEmail = userEmail;
		this.contactNo = contactNo;
	}
	
	

	public RegisteredUser_Admin(String userName) {
		super();
		this.userName = userName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "RegisteredUser_Admin [id=" + id + ", userName=" + userName + ", userEmail=" + userEmail + ", contactNo="
				+ contactNo + ", password=" + password + "]";
	}

	
	
	
}
