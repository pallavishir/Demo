package com.ofrs.Service;

import java.util.List;

import com.ofrs.Model.BookedFlights;


public interface BookedFlightsService_Admin {
	public List<BookedFlights> getBookedFlights();


}
