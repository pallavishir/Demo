package com.ofrs.Service;

import java.util.List;

import com.ofrs.DAO.BookedFlightsDAOImpl_Admin;
import com.ofrs.Model.BookedFlights;

public class BookedFlightsServiceImpl_Admin implements BookedFlightsService_Admin{

	BookedFlightsDAOImpl_Admin cancleTicketDao = new BookedFlightsDAOImpl_Admin();
	@Override
	public List<BookedFlights> getBookedFlights() {
		// TODO Auto-generated method stub
		return cancleTicketDao.getBookedFlights();
	}

}
