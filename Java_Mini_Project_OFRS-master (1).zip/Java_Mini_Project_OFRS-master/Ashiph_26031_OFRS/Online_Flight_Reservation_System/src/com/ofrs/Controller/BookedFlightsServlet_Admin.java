package com.ofrs.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ofrs.Model.BookedFlights;
import com.ofrs.Service.BookedFlightsService_Admin;
import com.ofrs.Service.BookedFlightsServiceImpl_Admin;


@WebServlet("/BookedFlightsServlet_Admin")
public class BookedFlightsServlet_Admin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private BookedFlightsServiceImpl_Admin cancleTicketService ;
	
	public void init()  {
		cancleTicketService = new BookedFlightsServiceImpl_Admin();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in cancle ticket servlet");
		List<BookedFlights> bookedFlightList = cancleTicketService.getBookedFlights();
		request.setAttribute("bookedFlightList", bookedFlightList);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("bookedFlightList_Admin.jsp");
		dispatcher.forward(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
