package com.ofrs.DAO;

import java.util.List;

import com.ofrs.Model.BookedFlights;

public interface BookedFlightsDAO_Admin {
	
	public List<BookedFlights> getBookedFlights();

}
