package com.ofrs.Model;

public class BookedFlights {
	
	private int id;
	private Flights_User flightId;
	private RegisteredUser_Admin userEmail;
	
	public BookedFlights() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookedFlights(int id, Flights_User flightId, RegisteredUser_Admin userEmail) {
		super();
		this.id = id;
		this.flightId = flightId;
		this.userEmail = userEmail;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Flights_User getFlightId() {
		return flightId;
	}

	public void setFlightId(Flights_User flightId) {
		this.flightId = flightId;
	}

	public RegisteredUser_Admin getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(RegisteredUser_Admin userEmail) {
		this.userEmail = userEmail;
	}

	@Override
	public String toString() {
		return "BookedFlights [id=" + id + ", flightId=" + flightId + ", userEmail=" + userEmail + "]";
	}
	
	

}
