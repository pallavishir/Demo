package com.ofrs.Model;

public class Flights_User {
	
	private int id;
	private String flightName;
	private String source;
	private String destination;
	private String departureDate;
	private String departureTime;
	private String flightStops;
	private Double price;
	
	public Flights_User() {}

	
	
	public Flights_User(String source, String destination, String departureDate) {
		super();
		this.source = source;
		this.destination = destination;
		this.departureDate = departureDate;
	}



	public Flights_User(int id, String flightName, String source, String destination, String departureDate,
			String departureTime, String flightStops, Double price) {
		super();
		this.id = id;
		this.flightName = flightName;
		this.source = source;
		this.destination = destination;
		this.departureDate = departureDate;
		this.departureTime = departureTime;
		this.flightStops = flightStops;
		this.price = price;
	}
	
	

	public Flights_User(String flightName, String source, String destination, String departureDate,
			String departureTime, Double price) {
		super();
		this.flightName = flightName;
		this.source = source;
		this.destination = destination;
		this.departureDate = departureDate;
		this.departureTime = departureTime;
		this.price = price;
	}
	
	

	public Flights_User(int id) {
		super();
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getFlightStops() {
		return flightStops;
	}

	public void setFlightStops(String flightStops) {
		this.flightStops = flightStops;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Flights_User [id=" + id + ", flightName=" + flightName + ", source=" + source + ", destination="
				+ destination + ", departureDate=" + departureDate + ", departureTime=" + departureTime
				+ ", flightStops=" + flightStops + ", price=" + price + "]";
	}

	

	
	
	
	
}
