package com.ofrs.Service;

import java.util.List;

import com.ofrs.DAO.RegisterUserDAOImp_Admin;
import com.ofrs.Model.RegisteredUser_Admin;

public class RegisterUserServiceImp_Admin implements RegisterUserService_Admin
{

	RegisterUserDAOImp_Admin registerUserDao = new RegisterUserDAOImp_Admin();
	
	@Override
	public List<RegisteredUser_Admin> getAllUsers() {
		// TODO Auto-generated method stub
		return registerUserDao.getAllUsers();
	}

}
