package com.ofrs.Service;

import com.ofrs.Model.Flights;

public interface AddFlightService {

	public void addFlight(Flights flights);
}
