package com.ofrs.Service;

import java.util.List;

import com.ofrs.Model.Flights;
import com.ofrs.Model.Flights_User;

public interface BookFlightService {

	public List<Flights_User> getFlights(String source,String  destination, String departureDate);
}
