package com.ofrs.Service;

import com.ofrs.DAO.AddFlightDAOImplementaion;
import com.ofrs.Model.Flights;

public class AddFlightServiceImplementation implements AddFlightService
{

	AddFlightDAOImplementaion addFlightDao = new AddFlightDAOImplementaion();
	
	@Override
	public void addFlight(Flights flights) {
		// TODO Auto-generated method stub
		 addFlightDao.addFlight(flights);
	}

}
