package com.ofrs.Service;

import java.util.List;

import com.ofrs.Model.BookedFlights;


public interface CancleTicketService {
	public List<BookedFlights> getBookedFlights();


}
