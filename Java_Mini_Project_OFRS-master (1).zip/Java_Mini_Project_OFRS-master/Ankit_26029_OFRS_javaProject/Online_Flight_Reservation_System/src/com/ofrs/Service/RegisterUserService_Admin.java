package com.ofrs.Service;

import java.util.List;

import com.ofrs.Model.RegisteredUser_Admin;

public interface RegisterUserService_Admin {
	public List<RegisteredUser_Admin> getAllUsers();
}
