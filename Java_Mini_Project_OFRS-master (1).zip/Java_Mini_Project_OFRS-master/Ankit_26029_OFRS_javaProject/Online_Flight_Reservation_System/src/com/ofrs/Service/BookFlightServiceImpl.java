package com.ofrs.Service;

import java.util.List;

import com.ofrs.DAO.BookFlightDAO;
import com.ofrs.DAO.BookFlightDAOImpl;
import com.ofrs.Model.Flights;
import com.ofrs.Model.Flights_User;

public class BookFlightServiceImpl implements BookFlightService {

	BookFlightDAOImpl bookFlightDao = new BookFlightDAOImpl();
	
	@Override
	public List<Flights_User> getFlights(String source, String destination, String departureDate) {
		
		return bookFlightDao.getFlights(source, destination, departureDate);
	}

	
}
