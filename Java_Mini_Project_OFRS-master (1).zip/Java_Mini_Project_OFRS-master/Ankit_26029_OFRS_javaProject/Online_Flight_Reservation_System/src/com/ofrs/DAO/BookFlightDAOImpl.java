package com.ofrs.DAO;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ofrs.JDBCUtility.JDBCUtility;
import com.ofrs.Model.BookedFlights;
import com.ofrs.Model.Flights;
import com.ofrs.Model.Flights_User;

public class BookFlightDAOImpl implements BookFlightDAO {

	
	private static final String FLIGHT_DETAILS = "SELECT * FROM flights WHERE source=? AND destination=? AND departureDate=?";
	
	
	
	
	@Override
	public List<Flights_User> getFlights(String source1,String  destination1, String departureDate1) {
		System.out.println(FLIGHT_DETAILS);
		
		Flights_User fUser= null;
		List<Flights_User> flightList = new ArrayList<Flights_User>();
		
		
		 try(Connection con = JDBCUtility.getConnection();
              	PreparedStatement ps = con.prepareStatement(FLIGHT_DETAILS); ){
	    	 ps.setString(1, source1);
	    	 ps.setString(2, destination1);
	    	 ps.setString(3, departureDate1);
	    	 
	    	 ResultSet rs = ps.executeQuery();
	    	 
	    	 while(rs.next()) {
	    		 int id = rs.getInt(1);
	    		 String flightName = rs.getString(2);
	    		 String source = rs.getString(3);
	    		 String destination = rs.getString(4);
	    		 String departureDate = rs.getString(5);
	    		 String departureTime = rs.getString(6);
	    		 String flightStops = rs.getString(7);
	    		 Double price = rs.getDouble(8);
	    		 
	    		 
	    flightList.add(new Flights_User(id, flightName, source, destination, departureDate, departureTime, flightStops, price));
	    	
	    		 
	    	 }
	    	 
	     } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flightList;
	}




	



	

	
}
