package com.ofrs.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ofrs.JDBCUtility.JDBCUtility;
import com.ofrs.Model.BookedFlights;
import com.ofrs.Model.Flights;

public class BookFlightImpl implements BookFlightDAO {

	
	private static final String FLIGHT_DETAILS = "select * from flights ";
	
	
	
	
	@Override
	public List<Flights> getFlights() {
		System.out.println(FLIGHT_DETAILS);
		
		List<Flights> flightList = new ArrayList<Flights>();
		
		
		 try(Connection con = JDBCUtility.getConnection();
              	PreparedStatement ps = con.prepareStatement(FLIGHT_DETAILS); ){
	    	 
	    	 ResultSet rs = ps.executeQuery();
	    	 
	    	 while(rs.next()) {
	    		 int id = rs.getInt(1);
	    		 int flightId = rs.getInt(2);
	    		 String userEmail = rs.getString(3);
	    		 
	    	//	 flightList.add(new BookedFlights(id,get));
	    		 
	    	 }
	    	 
	     } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	
}
