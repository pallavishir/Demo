package com.ofrs.DAO;

public class UpdateProfileDAO {

}
