package com.ofrs.DAO;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ofrs.JDBCUtility.JDBCUtility;
import com.ofrs.Model.BookedFlights;
import com.ofrs.Model.Flights_User;
import com.ofrs.Model.RegisteredUser_Admin;

public class CancleTicketDAOImpl implements CancleTicketDAO{
	
	
	
	private static final String TICKET_DETAILS = "select * from bookedflights ";
	
	private static final String GET_BY_ID = "select * from flights where flightId = ? ";
	
	private static final String GET_BY_USREMAIL = "select * from registeredusers where userEmail = ? ";
	
	private static final String CANCLE_TICKET = "delete from bookedflights where id = ?, userName = ? ";

	@Override
	public List<BookedFlights> getBookedFlights() {
	     System.out.println(TICKET_DETAILS);
	     
	     List<BookedFlights> bookedFlightList = new ArrayList<BookedFlights>();
	     
	     
	     
	     try(Connection con = JDBCUtility.getConnection();
                 	PreparedStatement ps = con.prepareStatement(TICKET_DETAILS); ){
	    	 
	    	 ResultSet rs = ps.executeQuery();
	    	 
	    	 while(rs.next()) {
	    		 int id = rs.getInt(1);
	    		 int flightId = rs.getInt(2);
	    		 String userEmail = rs.getString(3);
	    		 
	    		 bookedFlightList.add(new BookedFlights(id,getFlightById( id ),getByUserEmail(userEmail)));
	    		 
	    	 }
	    	 
	     } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
		return bookedFlightList;
	}
	
	public static Flights_User getFlightById(int flightId) {
		
		Flights_User flight = null;
	
		try(Connection con = JDBCUtility.getConnection();
                 	PreparedStatement ps = con.prepareStatement(GET_BY_ID);) {
			ps.setInt(1, flightId);
			
			ResultSet rs = ps.executeQuery();
			rs.next();
			
			String flightName = rs.getString(2);
			String source = rs.getString(3);
			String destination = rs.getString(4);
			String departureDate = rs.getString(5);
			String departureTime = rs.getString(6);
		    double price  = rs.getDouble(8);
		    
		    flight = new Flights_User(flightName, source, destination, departureDate, departureTime, price);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flight;
		
	}
	
	public static RegisteredUser_Admin getByUserEmail(String userEmail) {
		RegisteredUser_Admin user = null;
		
		try(Connection con = JDBCUtility.getConnection();
                 	PreparedStatement ps = con.prepareStatement(GET_BY_USREMAIL );) {
			ps.setString(1, userEmail);
			
			ResultSet rs = ps.executeQuery();
			rs.next();
			
			String userName = rs.getString(2);
		
//   user = new RegisteredUser_Admin(userName);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return user;
	}

}
