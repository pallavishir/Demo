package com.ofrs.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.ofrs.JDBCUtility.JDBCUtility;
import com.ofrs.Model.Flights;

public class AddFlightDAOImplementaion implements AddFlightDAO
{
	private static final String INSERT_FLIGHT = "INSERT INTO flights(flightName,source,destination,departureDate,departureTime,flightStops,price) VALUES(?,?,?,?,?,?,?)";

	@Override
	public void addFlight(Flights flights) {
		System.out.println(INSERT_FLIGHT);
		int result = 0;
		try(Connection con = JDBCUtility.getConnection();
				PreparedStatement ps = con.prepareStatement(INSERT_FLIGHT);){
			
			ps.setString(1, flights.getFlightName());
			ps.setString(2, flights.getSource());
			ps.setString(3, flights.getDestination());
			ps.setString(4, flights.getDepartureDate());
			ps.setString(5, flights.getDepartureTime());
			ps.setString(6, flights.getFlightStops());
			ps.setDouble(7, flights.getPrice());
			
			result = ps.executeUpdate();
			
			if(result>0) {
				System.out.println("Flight Added in Database!!!");
			}
			else {
				System.out.println("Failed to add Flight in DataBase!!");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
