package com.ofrs.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ofrs.JDBCUtility.JDBCUtility;
import com.ofrs.Model.RegisteredUser_Admin;

public class RegisterUserDAOImp_Admin implements RegisterUserDAO_Admin
{

	private static final String SELECT_ALL_REG_USER = "SELECT * FROM registeredusers";
	
	@Override
	public List<RegisteredUser_Admin> getAllUsers() {
		System.out.println(SELECT_ALL_REG_USER);
		
		List<RegisteredUser_Admin> regUserList = new ArrayList<RegisteredUser_Admin>();
		
		try(Connection con = JDBCUtility.getConnection();
				PreparedStatement ps = con.prepareStatement(SELECT_ALL_REG_USER);) {
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				int id = rs.getInt(1);
				String userName = rs.getString(2);
				String userEmail = rs.getString(3);
				String contactNo = rs.getString(4);
				
				regUserList.add(new RegisteredUser_Admin(id, userName, userEmail, contactNo));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return regUserList;
	}

}
