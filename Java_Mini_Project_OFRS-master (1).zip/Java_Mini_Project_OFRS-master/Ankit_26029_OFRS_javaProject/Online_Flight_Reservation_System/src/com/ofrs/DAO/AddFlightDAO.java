package com.ofrs.DAO;

import com.ofrs.Model.Flights;

public interface AddFlightDAO {

	public void addFlight(Flights flights);
	
	
}
