package com.ofrs.DAO;

import java.util.List;

import com.ofrs.Model.Flights;
import com.ofrs.Model.Flights_User;

public interface BookFlightDAO {

	public List<Flights_User> getFlights(String source,String  destination, String departureDate);
	
}
