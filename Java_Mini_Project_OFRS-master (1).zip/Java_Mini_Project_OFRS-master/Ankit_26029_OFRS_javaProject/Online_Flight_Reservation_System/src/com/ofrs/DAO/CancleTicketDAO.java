package com.ofrs.DAO;

import java.util.List;

import com.ofrs.Model.BookedFlights;

public interface CancleTicketDAO {
	
	public List<BookedFlights> getBookedFlights();

}
