package com.ofrs.DAO;

import java.util.List;

import com.ofrs.Model.RegisteredUser_Admin;

public interface RegisterUserDAO_Admin {

	public List<RegisteredUser_Admin> getAllUsers();
}
