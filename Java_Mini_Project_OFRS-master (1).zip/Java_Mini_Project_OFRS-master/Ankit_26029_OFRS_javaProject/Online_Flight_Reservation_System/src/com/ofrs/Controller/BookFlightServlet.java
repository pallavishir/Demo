package com.ofrs.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ofrs.Model.Flights;
import com.ofrs.Model.Flights_User;
import com.ofrs.Service.BookFlightServiceImpl;


@WebServlet("/BookFlightServlet")
public class BookFlightServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
		private BookFlightServiceImpl bookFlightService;
  
	
	public void init()  {
		
		bookFlightService = new BookFlightServiceImpl();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Inside BookFlight Servlet controller");
		
		String source = request.getParameter("source");
		String destination = request.getParameter("destination");
		String departureDate = request.getParameter("departureDate");
		
		List<Flights_User> flightList = bookFlightService.getFlights(source, destination, departureDate);
		request.setAttribute("flightList", flightList);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("bookingFlight.jsp");
		dispatcher.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
