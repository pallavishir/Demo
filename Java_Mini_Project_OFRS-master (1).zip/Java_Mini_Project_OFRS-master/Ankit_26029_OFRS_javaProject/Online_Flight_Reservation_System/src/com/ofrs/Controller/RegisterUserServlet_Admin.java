package com.ofrs.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ofrs.Model.RegisteredUser_Admin;
import com.ofrs.Service.AddFlightServiceImplementation;
import com.ofrs.Service.RegisterUserServiceImp_Admin;

/**
 * Servlet implementation class RegisterUserServlet_Admin
 */
@WebServlet("/RegisterUserServlet_Admin")
public class RegisterUserServlet_Admin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   private RegisterUserServiceImp_Admin regUserservice;
	
	public void init() {
		regUserservice = new RegisterUserServiceImp_Admin();
	    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<RegisteredUser_Admin> regUserList = regUserservice.getAllUsers();
		
		request.setAttribute("regUserList", regUserList);
		
		RequestDispatcher dispacher = request.getRequestDispatcher("registeredUserList.jsp");
		dispacher.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
