package com.ofrs.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ofrs.Model.Flights;
import com.ofrs.Service.AddFlightServiceImplementation;


@WebServlet("/AddFlightServlet")
public class AddFlightServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private AddFlightServiceImplementation addFlightservice;
	
	public void init() {
       addFlightservice = new AddFlightServiceImplementation();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("In Flight Servlet");
		String flightName = request.getParameter("flightName");
		String source = request.getParameter("source");
		String destination = request.getParameter("destination");
		String departureDate = request.getParameter("departureDate");
		String departureTime = request.getParameter("departureTime");
		String flightStops = request.getParameter("flightStops");
		double price = Integer.parseInt(request.getParameter("price"));
		
		Flights flights = new Flights(flightName, source, destination, departureDate, departureTime, flightStops, price);
		
		addFlightservice.addFlight(flights);
		
		RequestDispatcher dispacher = request.getRequestDispatcher("addFlight.jsp");
		dispacher.forward(request, response);
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
