package com.air.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ResetPassServlet
 */
@WebServlet("/ResetPassServlet")
public class ResetPassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResetPassServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{    
		// Get All parameters from Jsp Page
		String uemail= request.getParameter("username");
		// form se
		String oldpass= request.getParameter("oldpass");
		String newpass= request.getParameter("newpass");
		String renewpass= request.getParameter("renewpass");
		String email= request.getParameter("email");
		
		
		// To get old password from RegisterServlet
         HttpSession session = request.getSession();
         // In Login Servlet , setting vaue of password which got from database  into "password" key
         String cpass="";
         try {
         Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/ofrs", "root", "root");
		//To fetch old password from database
		PreparedStatement pst1=con1.prepareStatement("select password from registeredusers where userEmail=?");
		pst1.setString(1, email);
		ResultSet rs1=pst1.executeQuery();
		if(rs1.next() ) {
			//old password from database
			cpass=rs1.getString(1);
			
		}
               
         }catch(Exception e){
        	 e.printStackTrace();;
         }
         String uname=(String)session.getAttribute("name");
		
		RequestDispatcher  dispatcher=null;
		 
		// If any field is blank
		if(oldpass.equals(null) || oldpass=="" || newpass.equals(null) || newpass=="" ||  renewpass.equals(null) || renewpass=="")
		{
			// Attribute key is status
			request.setAttribute("status", "All Fields are mandatory");
			dispatcher= request.getRequestDispatcher("UpdatePassword.jsp");
			//To redirect to registration.jsp. again becoz uname is not entered
			dispatcher.forward(request, response);
		}
		//If newpassword Not matching with retype password
		else if(!newpass.equals(renewpass))
		{
			// Attribute key is status
			request.setAttribute("status", "Password does NOT match");
			dispatcher= request.getRequestDispatcher("UpdatePassword.jsp");
			//To redirect to registration.jsp. again becoz uname is not entered
			dispatcher.forward(request, response);
		}
		
		// If old password fetched from database(cpass) and just entered password by user(oldpass) are NOT equal
		else if(! cpass.equals(oldpass))
		{
			// Attribute key is status
		   request.setAttribute("status", "Old Password is NOT correct");
			dispatcher= request.getRequestDispatcher("UpdatePassword.jsp");
			//To redirect to registration.jsp. again becoz uname is not entered
			dispatcher.forward(request, response);
		}
		else if(newpass.equals(renewpass))
		{
			// Attribute key is status
			   request.setAttribute("status", "success");
				dispatcher= request.getRequestDispatcher("UpdatePassword.jsp");
				//To redirect to registration.jsp. again becoz uname is not entered
				dispatcher.forward(request, response);
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ofrs", "root", "Durga@123");
			// To check wheathrr uemail and upwd (provided by logged user) exist in database users or Not
			PreparedStatement pst=con.prepareStatement("update registeredusers set password=? where  userEmail=?"); // email & pwd are fields in database users Do not take as uemail plz
			
			pst.setString(1,  newpass);
			pst.setString(2,  email);
			
			
			
			// select query so use executeQuery method it will return resultset rs
			int rs =pst.executeUpdate();
		  System.out.println(newpass + "" + email);
			
			// rs.next() -> If resultset has data means if we got found record email & password  in database users then user is already existing in database users
			// So user is existing so redirect user to Home page
		  //Success hua update then rs=1
			if(rs==1)
			{   
				System.out.println("Inside ");
				dispatcher = request.getRequestDispatcher("login.jsp");
				dispatcher.forward(request, response);
				// In index.jsp we have used session  so here also use session (Not request)
//				session.setAttribute("oldpass", rs.getString("password")); // In database users column name is "name" (NOT uname)
//				session.setAttribute("newpass", rs.getString("password")); // In database users column name is "password" (NOT pass)
				// If user has logged in successfully then redirect user to Home page i.e. index.jsp using RequestDispatcher or sendRedirect
				
				
			}
			else
			{
				// User has given Wrong username or Password
				request.setAttribute("status", "failed");
				dispatcher= request.getRequestDispatcher("login.jsp");
				dispatcher.forward(request, response);

			}
			
		
						
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		}
		
	}
}
