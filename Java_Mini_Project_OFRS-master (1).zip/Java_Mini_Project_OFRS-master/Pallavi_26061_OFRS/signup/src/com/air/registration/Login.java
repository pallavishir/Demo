package com.air.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login
 */
@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{ 
		// Get looged in details of user
		String uemail= request.getParameter("username");
		String upwd= request.getParameter("password");
		HttpSession session =  request.getSession();
		RequestDispatcher dispatcher= null;
		
		// If user has not entered email or if email is empty space
		if( uemail == null ||  uemail.equals(""))
		{ 
			// Attribute key is status
			request.setAttribute("status", "invalidEmail");
			dispatcher= request.getRequestDispatcher("login.jsp");
			//To redirect to login.jsp again
			dispatcher.forward(request, response);
		}
		
		
		if( upwd == null ||  upwd.equals(""))
		{ 
			// Attribute key is status
			request.setAttribute("status", "invalidUpwd ");
			dispatcher= request.getRequestDispatcher("login.jsp");
			//To redirect to login.jsp again
			dispatcher.forward(request, response);
		}
		
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ofrs", "root", "root");
			// To check wheathrr uemail and upwd (provided by logged user) exist in database users or Not
			PreparedStatement pst=con.prepareStatement("select * from  registeredusers  where userEmail=? and password=?"); // email & pwd are fields in database users Do not take as uemail plz
			
			pst.setString(1, uemail);
			pst.setString(2, upwd);
			
			
			
			// select query so use executeQuery method it will return resultset rs
			ResultSet rs =pst.executeQuery();
		
			
			// rs.next() -> If resultset has data means if we got found record email & password  in database users then user is already existing in database users
			// So user is existing so redirect user to Home page
			if(rs.next())
			{   
				// In index.jsp we have used session  so here also use session (Not request)
				session.setAttribute("userEmail", rs.getString("userName")); // In database users column name is "name" (NOT uname)
				session.setAttribute("password", rs.getString("password")); // In database users column name is "password" (NOT pass)
				// If user has logged in successfully then redirect user to Home page i.e. index.jsp using RequestDispatcher or sendRedirect
				dispatcher= request.getRequestDispatcher("index.jsp");
				
			}
			else
			{
				// User has given Wrong username or Password
				request.setAttribute("status", "failed");
				dispatcher= request.getRequestDispatcher("login.jsp");
			}
			
			dispatcher.forward(request, response);
			
						
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}

}
