package com.cybage.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cybage.model.Offers;

public class OffersDAO {

	private String jdbcURL = "jdbc:mysql://localhost:3306/flights?useSSL=false";
	private String jdbcUsername = "root";
	private String jdbcPassword = "root";

	private static final String INSERT_OFFERS_SQL = "INSERT INTO offers" + "(discount, name, flightName, couponCode) VALUES "
			+ " (?, ?, ?, ?);";

	private static final String SELECT_OFFERS_BY_ID = "select name, flightName, discount, couponCode from offers where id =?;";
	private static final String SELECT_ALL_OFFERS = "select * from offers";
	private static final String DELETE_OFFERS_SQL = "delete from offers where id = ?;";
	private static final String UPDATE_OFFERS_SQL = "update offers name = ?, flightName = ?, discount = ?, couponCode = ? where id = ?;";

	public OffersDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertOffer(Offers offer) throws SQLException {
		System.out.println(INSERT_OFFERS_SQL);
		// try-with-resource statement will auto close the connection.
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_OFFERS_SQL)) {
			preparedStatement.setString(1, offer.getName());
			preparedStatement.setString(2, offer.getFlightName());
			preparedStatement.setInt(3, offer.getDiscount());
			preparedStatement.setString(4, offer.getCouponCode());
			
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Offers selectOffer(int id) {
		Offers offer = null;
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_OFFERS_BY_ID);) {
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String name = rs.getString("name");
				String flightName = rs.getString("flightName");
				int discount = rs.getInt("discount");
				String couponCode = rs.getString("couponCode");
				offer = new Offers(id, discount, name, flightName, couponCode);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return offer;
	}

	public List<Offers> selectAllOffers() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Offers> offer = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_OFFERS);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int id = rs.getInt("id");
				int discount = rs.getInt("discount");
				String name = rs.getString("name");
				String flightName = rs.getString("flightName");
				String couponCode = rs.getString("couponCode");
				offer.add(new Offers(id, discount, name, flightName, couponCode));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return offer;
	}

	public boolean deleteOffer(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_OFFERS_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateOffers(Offers offer) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_OFFERS_SQL);) {
			
			statement.setInt(1, offer.getId());
			statement.setInt(2, offer.getDiscount());
			statement.setString(3, offer.getName());
			statement.setString(4, offer.getFlightName());
			statement.setString(5, offer.getCouponCode());
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
}