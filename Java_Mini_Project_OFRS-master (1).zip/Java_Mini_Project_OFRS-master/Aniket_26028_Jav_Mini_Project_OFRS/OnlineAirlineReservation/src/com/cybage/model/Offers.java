package com.cybage.model;

public class Offers {

	@Override
	public String toString() {
		return "Offers [id=" + id + ", discount=" + discount + ", name=" + name + ", flightName=" + flightName
				+ ", couponCode=" + couponCode + "]";
	}
	int id, discount;
	String name, flightName, couponCode;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public Offers(int id, int discount, String name, String flightName, String couponCode) {
		super();
		this.id = id;
		this.discount = discount;
		this.name = name;
		this.flightName = flightName;
		this.couponCode = couponCode;
	}
	public Offers(int discount, String name, String flightName, String couponCode) {
		super();
		this.discount = discount;
		this.name = name;
		this.flightName = flightName;
		this.couponCode = couponCode;
	}
	public Offers() {
		super();
	}	
}
