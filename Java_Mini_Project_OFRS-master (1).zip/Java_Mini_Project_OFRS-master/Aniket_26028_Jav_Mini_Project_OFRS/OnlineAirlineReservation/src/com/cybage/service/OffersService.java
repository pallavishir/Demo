package com.cybage.service;

public class OffersService {

}
