package com.cybage.service;

public class FlightsService {

}
