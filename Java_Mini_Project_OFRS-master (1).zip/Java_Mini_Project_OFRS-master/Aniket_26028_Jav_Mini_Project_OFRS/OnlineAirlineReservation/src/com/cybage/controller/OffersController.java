package com.cybage.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.dao.OffersDAO;
import com.cybage.model.Offers;

/**
 * Servlet implementation class OffersController
 */
@WebServlet("/OffersController")
public class OffersController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private OffersDAO offersDAO;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OffersController() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void init() {
		offersDAO = new OffersDAO();
	}
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/newOffer":
				showNewForm(request, response);
				break;
			case "/insertOffer":
				insertOffer(request, response);
				break;
			case "/deleteOffer":
				deleteOffer(request, response);
				break;
			case "/editOffer":
				showEditForm(request, response);
				break;
			case "/updateOffer":
				updateOffer(request, response);
				break;
			default:
				listOffers(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listOffers(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Offers> listOffers = offersDAO.selectAllOffers();
		System.out.println(listOffers);
		request.setAttribute("listOffers", listOffers);
		RequestDispatcher dispatcher = request.getRequestDispatcher("offers-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("offers-form.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Offers offer = offersDAO.selectOffer(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("offers-form.jsp");
		System.out.println(offer);
		request.setAttribute("offer", offer);
		dispatcher.forward(request, response);

	}

	private void insertOffer(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		String name = request.getParameter("name");
		String flightName = request.getParameter("flightName");
		String couponCode = request.getParameter("couponCode");
		int discount = Integer.parseInt(request.getParameter("discount"));
		Offers offer = new Offers(discount, name, flightName, couponCode);
		System.out.println(offer);
		offersDAO.insertOffer(offer);
		response.sendRedirect("listOffer");
	}

	private void updateOffer(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		int discount = Integer.parseInt(request.getParameter("discount"));
		String name = request.getParameter("name");
		String flightName = request.getParameter("flightName");
		String couponCode = request.getParameter("couponCode");

		Offers offer = new Offers(id, discount, name, flightName, couponCode);
		System.out.println(offer);
		offersDAO.updateOffers(offer);
		response.sendRedirect("listOffer");
	}

	private void deleteOffer(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		offersDAO.deleteOffer(id);
		response.sendRedirect("listOffer");
	}

}