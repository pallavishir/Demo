package com.cybage.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.dao.FlightsDAO;
import com.cybage.dao.OffersDAO;
import com.cybage.model.Flights;

/**
 * Servlet implementation class FlightsServlet
 */
@WebServlet("/")
public class FlightsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private FlightsDAO flightsDAO;
	public void init() {
		flightsDAO = new FlightsDAO();
		new OffersDAO();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertFlight(request, response);
				break;
			case "/delete":
				deleteFlight(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateFlight(request, response);
				break;
			default:
				listFlights(request, response);
				break;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	private void listFlights(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Flights> listFlights = flightsDAO.selectAllFlights();
		request.setAttribute("listFlight", listFlights);
		RequestDispatcher dispatcher = request.getRequestDispatcher("flight-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("flight-form.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Flights existingFlight = flightsDAO.selectFlight(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("flight-form.jsp");
		request.setAttribute("flight", existingFlight);
		dispatcher.forward(request, response);

	}

	private void insertFlight(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		String flightName = request.getParameter("flightName");
		String source = request.getParameter("source");
		String destination = request.getParameter("destination");
		String departureDate = request.getParameter("departureDate");
		String departureTime = request.getParameter("departureTime");
		String flightStops = request.getParameter("flightStops");
		String price = request.getParameter("price");
		Flights flight = new Flights(flightName, source, destination, departureDate, departureTime, flightStops, price);
		flightsDAO.insertFlight(flight);
		response.sendRedirect("listFlight");
	}

	private void updateFlight(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String flightName = request.getParameter("flightName");
		String source = request.getParameter("source");
		String destination = request.getParameter("destination");
		String departureDate = request.getParameter("departureDate");
		String departureTime = request.getParameter("departureTime");
		String flightStops = request.getParameter("flightStops");
		String price = request.getParameter("price");
		Flights flight = new Flights(id, flightName, source, destination, departureDate, departureTime, flightStops, price);
		flightsDAO.updateFlight(flight);
		response.sendRedirect("listFlight");
	}

	private void deleteFlight(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		flightsDAO.deleteFlight(id);
		response.sendRedirect("listFlight");

	}

}
