package com.ofrs.Service;

import java.util.List;

import com.ofrs.DAO.CancleTicketDAOImpl;
import com.ofrs.Model.BookedFlights;

public class CancleTicketServiceImpl implements CancleTicketService{

	CancleTicketDAOImpl cancleTicketDao = new CancleTicketDAOImpl();
	@Override
	public List<BookedFlights> getBookedFlights() {
		// TODO Auto-generated method stub
		return cancleTicketDao.getBookedFlights();
	}

}
